
package donationproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Doner {
    String name ;
    String address ;
    String email;
    String phoneNumber ;
    String monthlyIncome ;
    String password ;
    public static boolean loginUser(String loginEmail, String loginPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader("doner_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userInfo = line.split(",");
                String email = userInfo[2].trim(); 
                String password = userInfo[5].trim();

                if (loginEmail.trim().equalsIgnoreCase(email) && loginPassword.equals(password)) {
                    return true; 
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
return false;
    
    }}
