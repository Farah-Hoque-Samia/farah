package donationproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class User {
    private static ArrayList<String> usersWithCampaign = new ArrayList<>();
    private String fullName;
    private String contact;
    private String email;
    private String password;

    public User(String fullName, String contact, String email, String password) {
        this.fullName = fullName;
        this.contact = contact;
        this.email = email;
        this.password = password;
    }

    public static ArrayList<String> getUsersWithCampaign() {
        return usersWithCampaign;
    }

    public static void setUsersWithCampaign(ArrayList<String> usersWithCampaign) {
        User.usersWithCampaign = usersWithCampaign;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public static boolean loginUser(String loginEmail, String loginPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader("donee_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userInfo = line.split("  ");
                String email = userInfo[2].trim();
                String password = userInfo[5].trim();

                if (loginEmail.trim().equalsIgnoreCase(email) && loginPassword.equals(password)) {
                    return true;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static boolean hasAddedCampaign(String userEmail) {
        return usersWithCampaign.contains(userEmail);
    }

    public static void markCampaignAdded(String userEmail) {
        usersWithCampaign.add(userEmail);
    }
}
