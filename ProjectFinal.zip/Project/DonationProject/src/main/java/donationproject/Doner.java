
package donationproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Doner {
    String id;
    String name ;
    String address ;
    String email;
    String phoneNumber ;
    String monthlyIncome ;
    String password ;
    public static boolean loginDoner(String loginName, String loginPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader("doner_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userInfo = line.split("  ");
                String name = userInfo[0].trim(); 
                String password = userInfo[5].trim();

                if (loginName.trim().equalsIgnoreCase(name) && loginPassword.equals(password)) {
                    return true; 
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
return false;
    
    }}
