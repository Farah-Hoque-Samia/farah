package donationproject;

public class DonationProject {

    public static void main(String[] args) {
        NewJFrame j = new NewJFrame();
        j.setVisible(true);
        j.pack();
        j.setLocationRelativeTo(null);
    }
}
