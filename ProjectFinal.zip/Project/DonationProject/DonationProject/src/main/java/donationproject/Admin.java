
package donationproject;

public class Admin {
    
}
